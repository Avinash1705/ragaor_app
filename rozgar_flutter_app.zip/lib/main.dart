
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

void main() {
  runApp(const ProviderScope(child: RozgarApp()));
}

class RozgarApp extends StatelessWidget {
  const RozgarApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Rozgar',
      theme: ThemeData.dark(),
      home: const Scaffold(
        body: Center(child: Text('Rozgar Flutter Riverpod App')),
      ),
    );
  }
}
